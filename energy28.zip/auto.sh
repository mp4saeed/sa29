#!/bin/bash
COUNTER=1
while(true) do
./energy.sh
let COUNTER=COUNTER+1 
done
